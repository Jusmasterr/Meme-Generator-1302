function loadTemplate() {
    const input = document.getElementById('templateInput');
    const memeContainer = document.getElementById('memeContainer');
    const memeTemplate = document.getElementById('memeTemplate');
    const captionInput = document.getElementById('captionInput');

    const file = input.files[0];

    if (file) {
        const reader = new FileReader();

        reader.onload = function (e) {
            memeTemplate.src = e.target.result;
            memeContainer.style.display = 'block';
        };

        reader.readAsDataURL(file);
    } else {
        memeContainer.style.display = 'none';
    }

    captionInput.value = '';
}

function loadRndTemplate() {
    const rndNumber = Math.floor(Math.random() * 4) + 1;
    memeTemplate.src = rndNumber + ".jpg";
}

function template1Load() {
    memeTemplate.src = "1.jpg";
}

function template2Load() {
    memeTemplate.src = "2.jpg";
}

function template3Load() {
    memeTemplate.src = "3.jpg";
}

function template4Load() {
    memeTemplate.src = "4.jpg";
}